import { useState, useEffect, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { track } from "@/lib/analytics";
import { cn } from "@/lib/utils";

/**
 * Types & Constants
 */
interface Notification {
  name: string;
  action: string;
  initial: string;
  location?: string;
  isSystem?: boolean;
}

const NOTIFICATIONS: Notification[] = [
  { name: "María Ferrer", location: "Valencia", action: "acaba de reservar una llamada", initial: "MF" },
  { name: "Jorge Ruiz", location: "restaurante", action: "automatizó sus reservas esta semana", initial: "JR" },
  { name: "Lucía Navarro", location: "Sevilla", action: "nos escribió hace 2 horas", initial: "LN" },
  { name: "Carlos Gomis", location: "Alicante", action: "solicitó una auditoría gratuita", initial: "CG" },
  { name: "Elena Sanz", location: "clínica", action: "ahorra 12h/semana con el nuevo sistema", initial: "ES" },
  { name: "Pedro Soto", location: "Madrid", action: "acaba de contratar el Plan Negocio", initial: "PS" },
  { name: "Marta Vila", location: "Barcelona", action: "conectó su agenda con WhatsApp", initial: "MV" },
  { name: "Fran López", location: "taller", action: "recuperó 400€ en tiempo perdido hoy", initial: "FL" },
  { isSystem: true, name: "Disponibilidad", action: "Solo quedan 2 plazas para junio", initial: "AF" },
];

const AVATAR_STYLES = [
  "bg-aura-peach/25 ring-aura-peach/40",
  "bg-aura-lavender/30 ring-aura-lavender/50",
  "bg-aura-ink/10 ring-aura-ink/20",
];

const TIMINGS = {
  INITIAL_MIN: 8000,
  INITIAL_MAX: 15000,
  ROTATION_BASE: 45000,
  ROTATION_VARIANCE: 15000,
  AUTO_HIDE: 5000,
  GLOBAL_STOP: 120000, // 2 minutes to avoid fatigue
};

/**
 * useNotificationCycle: Custom hook to manage the lifecycle of social proof pulses.
 */
function useNotificationCycle() {
  const [index, setIndex] = useState(0);
  const [visible, setVisible] = useState(false);
  const [stopCycling, setStopCycling] = useState(false);

  const showNext = useCallback(() => {
    if (stopCycling) return;
    
    setIndex((prev) => {
      let next = Math.floor(Math.random() * NOTIFICATIONS.length);
      if (next === prev) next = (next + 1) % NOTIFICATIONS.length;
      return next;
    });

    setVisible(true);
    setTimeout(() => setVisible(false), TIMINGS.AUTO_HIDE);
  }, [stopCycling]);

  useEffect(() => {
    const initialDelay = Math.floor(Math.random() * (TIMINGS.INITIAL_MAX - TIMINGS.INITIAL_MIN + 1) + TIMINGS.INITIAL_MIN);
    const startTimeout = setTimeout(showNext, initialDelay);
    const globalTimeout = setTimeout(() => setStopCycling(true), TIMINGS.GLOBAL_STOP);

    const interval = setInterval(() => {
      const nextDelay = Math.floor(Math.random() * TIMINGS.ROTATION_VARIANCE);
      setTimeout(showNext, nextDelay);
    }, TIMINGS.ROTATION_BASE);

    return () => {
      clearTimeout(startTimeout);
      clearTimeout(globalTimeout);
      clearInterval(interval);
    };
  }, [showNext]);

  useEffect(() => {
    if (visible) {
      const item = NOTIFICATIONS[index];
      track("social_proof_shown", { message: `${item.name} ${item.action}` });
    }
  }, [visible, index]);

  return { current: NOTIFICATIONS[index], index, visible, stopCycling };
}

/**
 * SocialProofToast: Main Component
 */
export function SocialProofToast() {
  const { current, index, visible, stopCycling } = useNotificationCycle();

  if (!visible || stopCycling) return null;

  return (
    <AnimatePresence>
      <motion.div
        key={index}
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: -100, opacity: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className={cn(
          "fixed bottom-6 left-6 z-[60] hidden sm:flex items-center gap-4 rounded-2xl border border-aura-ink/10 bg-white/80 p-3 pr-6 shadow-[0_15px_40px_-15px_rgba(0,0,0,0.15)] backdrop-blur-xl",
          current.isSystem && "border-aura-peach/30"
        )}
      >
        <NotificationAvatar item={current} index={index} />
        <NotificationContent item={current} />
      </motion.div>
    </AnimatePresence>
  );
}

/**
 * Internal UI Components
 */
function NotificationAvatar({ item, index }: { item: Notification; index: number }) {
  const avatarStyle = useMemo(() => 
    item.isSystem ? "bg-aura-ink text-white ring-aura-ink/20" : AVATAR_STYLES[index % AVATAR_STYLES.length],
  [item.isSystem, index]);

  return (
    <div className="relative">
      <span className={cn("flex h-10 w-10 items-center justify-center rounded-full font-display text-xs font-medium ring-1", avatarStyle)}>
        {item.initial}
      </span>
      <motion.span
        animate={{ scale: [1, 1.4, 1], opacity: [0.8, 1, 0.8] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className={cn(
          "absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-white",
          item.isSystem ? "bg-aura-peach" : "bg-green-500"
        )}
      />
    </div>
  );
}

function NotificationContent({ item }: { item: Notification }) {
  return (
    <div className="flex flex-col text-sm leading-tight">
      <span className={cn("font-semibold", item.isSystem ? "text-aura-peach" : "text-aura-ink")}>
        {item.name} {item.location && <span className="font-normal opacity-60">de {item.location}</span>}
      </span>
      <span className="text-aura-ink/70">{item.action}</span>
    </div>
  );
}

